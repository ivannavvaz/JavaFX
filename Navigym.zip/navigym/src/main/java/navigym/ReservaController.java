package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class ReservaController {

    // Excepciones

    class ClaseNoEncontradaException extends Exception {
        public ClaseNoEncontradaException(String mensaje) {
            super(mensaje);
        }
    }

    class ClaseLlenaException extends Exception {
        public ClaseLlenaException(String mensaje) {
            super(mensaje);
        }
    }

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button botonDisponibilidad;

    @FXML
    private Button botonReservar;

    @FXML
    private DatePicker fecha;

    @FXML
    private ChoiceBox<String> tipoClase;

    @FXML
    private TableView tablaClases;
    @FXML
    private TableColumn idCL;
    @FXML
    private TableColumn claseCL;
    @FXML
    private TableColumn fechaCL;
    @FXML
    private TableColumn capacidadActualCL;
    @FXML
    private TableColumn capacidadCL;
    ObservableList<clase> clases;

    private void inicializarTablaClases() {

        idCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("id"));
        claseCL.setCellValueFactory(new PropertyValueFactory<clase, String>("nombre"));
        fechaCL.setCellValueFactory(new PropertyValueFactory<clase, String>("fecha"));
        capacidadActualCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("capacidadActual"));
        capacidadCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("capacidad"));

        clases = FXCollections.observableArrayList();
        tablaClases.setItems(clases);

    }

    @FXML
    void verDisponibilidad(ActionEvent event) {

        tablaClases.getItems().clear();

        if (tipoClase.getValue() == null && fecha.getValue() == null) {

            try {

                App.con = App.conectar();
                Statement st = App.con.createStatement();
                ResultSet rs1 = st.executeQuery("SELECT * FROM clases");

                while (rs1.next()) {

                    clases.add(new clase(rs1.getInt("id"), rs1.getString("nombre"), rs1.getInt("capacidadActual"),
                            rs1.getInt("capacidad"), rs1.getString("fecha"), rs1.getString("dni")));

                }

            } catch (Exception e) {

                System.out.println("ERROR - " + e.getMessage());

            }

        } else if (tipoClase.getValue() == null) {

            try {

                App.con = App.conectar();
                Statement st = App.con.createStatement();
                ResultSet rs1 = st.executeQuery("SELECT * FROM clases");

                while (rs1.next()) {

                    if (rs1.getString("fecha").toString().contains(fecha.getValue().toString())) {

                        clases.add(new clase(rs1.getInt("id"), rs1.getString("nombre"), rs1.getInt("capacidadActual"),
                                rs1.getInt("capacidad"), rs1.getString("fecha"), rs1.getString("dni")));

                    }

                }

            } catch (Exception e) {

                System.out.println("ERROR - " + e.getMessage());

            }

        } else if (fecha.getValue() == null || fecha.getValue().toString().equals("")) {

            try {

                App.con = App.conectar();
                Statement st = App.con.createStatement();
                ResultSet rs1 = st.executeQuery("SELECT * FROM clases");

                while (rs1.next()) {

                    if (rs1.getString("nombre").equals(tipoClase.getValue())) {

                        clases.add(new clase(rs1.getInt("id"), rs1.getString("nombre"), rs1.getInt("capacidadActual"),
                                rs1.getInt("capacidad"), rs1.getString("fecha"), rs1.getString("dni")));

                    }

                }

            } catch (Exception e) {

                System.out.println("ERROR - " + e.getMessage());

            }

        } else {

            try {

                App.con = App.conectar();
                Statement st = App.con.createStatement();
                ResultSet rs1 = st.executeQuery("SELECT * FROM clases");

                while (rs1.next()) {

                    if (rs1.getString("nombre").equals(tipoClase.getValue())
                            && rs1.getString("fecha").toString().contains(fecha.getValue().toString())) {

                        clases.add(new clase(rs1.getInt("id"), rs1.getString("nombre"), rs1.getInt("capacidadActual"),
                                rs1.getInt("capacidad"), rs1.getString("fecha"), rs1.getString("dni")));

                    }

                }

            } catch (Exception e) {

                System.out.println("ERROR - " + e.getMessage());

            }

        }

        fecha.setValue(null);

    }

    clase claseSeleccionada = null;

    @FXML
    void reservar(ActionEvent event) {

        if (clases.size() != 0) {

            claseSeleccionada = clases.get(tablaClases.getSelectionModel().getFocusedIndex());

        }

        if (claseSeleccionada != null) {

            try {

                if (claseSeleccionada.getCapacidad() > claseSeleccionada.getCapacidadActual()) {

                    PreparedStatement ps;
                    String sql = "insert into usuarioApuntanClases(dni, id) values(?,?)";
                    ps = App.con.prepareStatement(sql);
                    ps.setString(1, LoginController.usuarioIniciado.getDni());
                    ps.setInt(2, claseSeleccionada.getId());
                    ps.executeUpdate();

                    PreparedStatement ps1;
                    String sql1 = "update clases set capacidadActual = capacidadActual + 1 where id = ?";
                    ps1 = App.con.prepareStatement(sql1);
                    ps1.setInt(1, claseSeleccionada.getId());
                    ps1.executeUpdate();

                    App.clasesReservadas
                            .add(new clase(claseSeleccionada.getId(), claseSeleccionada.getNombre(),
                                    claseSeleccionada.getCapacidadActual()+1,
                                    claseSeleccionada.getCapacidad(), claseSeleccionada.getFecha(),
                                    claseSeleccionada.getDni()));

                    App.usuarioApuntanClasesArray.add(new usuarioApuntanClase(LoginController.usuarioIniciado.getDni(), claseSeleccionada.getId()));

                    clases.clear();

                    Alert claseNoEncontrada = new Alert(Alert.AlertType.CONFIRMATION);
                    claseNoEncontrada.setTitle("");
                    claseNoEncontrada.setHeaderText("Clase reservada");
                    claseNoEncontrada
                            .setContentText(claseSeleccionada.getFecha() + " - " + claseSeleccionada.getNombre());
                    claseNoEncontrada.showAndWait();

                } else {

                    throw new ClaseLlenaException("Clase llena");

                }

            } catch (SQLException e) {

                Alert error = new Alert(Alert.AlertType.ERROR);
                error.setTitle("");
                error.setHeaderText("!! ERROR ¡¡");
                error.setContentText("Ya estas apuntado a esa clase");
                error.showAndWait();

            } catch (ClaseLlenaException e) {

                Alert claseNoEncontrada = new Alert(Alert.AlertType.ERROR);
                claseNoEncontrada.setTitle("");
                claseNoEncontrada.setHeaderText("!! ERROR ¡¡");
                claseNoEncontrada.setContentText(e.getMessage());
                claseNoEncontrada.showAndWait();

            } finally {

            claseSeleccionada = null;

            }

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("principal");
    }

    @FXML
    void initialize() {
        assert botonDisponibilidad != null
                : "fx:id=\"botonDisponibilidad\" was not injected: check your FXML file 'reserva.fxml'.";
        assert botonReservar != null : "fx:id=\"botonReservar\" was not injected: check your FXML file 'reserva.fxml'.";
        assert capacidadActualCL != null
                : "fx:id=\"capacidadActualCL\" was not injected: check your FXML file 'reserva.fxml'.";
        assert capacidadCL != null : "fx:id=\"capacidadCL\" was not injected: check your FXML file 'reserva.fxml'.";
        assert claseCL != null : "fx:id=\"claseCL\" was not injected: check your FXML file 'reserva.fxml'.";
        assert fecha != null : "fx:id=\"fecha\" was not injected: check your FXML file 'reserva.fxml'.";
        assert fechaCL != null : "fx:id=\"fechaCL\" was not injected: check your FXML file 'reserva.fxml'.";
        assert idCL != null : "fx:id=\"idCL\" was not injected: check your FXML file 'reserva.fxml'.";
        assert tablaClases != null : "fx:id=\"tablaClases\" was not injected: check your FXML file 'reserva.fxml'.";
        assert tipoClase != null : "fx:id=\"tipoClase\" was not injected: check your FXML file 'reserva.fxml'.";
        tipoClase.getItems().add(null);
        tipoClase.getItems().add("Bodypump");
        tipoClase.getItems().add("Bodycombat");
        tipoClase.getItems().add("Yoga");
        tipoClase.getItems().add("Spinning");
        tipoClase.getItems().add("Crossfit");
        this.inicializarTablaClases();

    }

}
