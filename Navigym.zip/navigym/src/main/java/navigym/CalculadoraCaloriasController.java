package navigym;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class CalculadoraCaloriasController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ChoiceBox<String> actividad;

    @FXML
    private TextField altura;

    @FXML
    private TextField edad;

    @FXML
    private ChoiceBox<String> genero;

    @FXML
    private TextField kilogramos;

    @FXML
    private TextField resultado;

    @FXML
    private ImageView volver;

    @FXML
    void calcular(ActionEvent event) {

        if (genero.getValue() == null || actividad.getValue() == null || edad.getText().isEmpty()
                || kilogramos.getText().isEmpty() || altura.getText().isEmpty()) {

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("");
            error.setHeaderText("!! ERROR ¡¡");
            error.setContentText("Debes rellenar todos los campos");
            error.showAndWait();

        } else if (!edad.getText().matches("[0-9]+")) {

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("");
            error.setHeaderText("!! ERROR ¡¡");
            error.setContentText("En el campo edad debes introducir un numero");
            error.showAndWait();

        } else if (!kilogramos.getText().matches("[0-9]+")) {

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("");
            error.setHeaderText("!! ERROR ¡¡");
            error.setContentText("En el campo kilogramos debes introducir un numero");
            error.showAndWait();

        } else if (!altura.getText().matches("[0-9]+")) {

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("");
            error.setHeaderText("!! ERROR ¡¡");
            error.setContentText("En el campo altura debes introducir un numero");
            error.showAndWait();

        } else {

            float tmb = 0;

            if (genero.getValue().equals("Hombre")) {

                tmb = (10 * Float.parseFloat(kilogramos.getText())) + (6.25f * Float.parseFloat(altura.getText()))
                        - (5 * Float.parseFloat(edad.getText())) + 5;

            } else if (genero.getValue().equals("Mujer")) {

                tmb = (10 * Float.parseFloat(kilogramos.getText())) + (6.25f * Float.parseFloat(altura.getText()))
                        - (5 * Float.parseFloat(edad.getText())) - 161;

            }

            if (actividad.getValue().contains("Sedentario")) {

                tmb = tmb * 1.2f;

            } else if (actividad.getValue().contains("Poca actividad fisica")) {

                tmb = tmb * 1.375f;

            } else if (actividad.getValue().contains("Actividad moderada")) {

                tmb = tmb * 1.55f;

            } else if (actividad.getValue().contains("Actividad intensa")) {

                tmb = tmb * 1.725f;

            } else if (actividad.getValue().contains("Athleta profesional")) {

                tmb = tmb * 1.9f;

            }

            tmb = Math.round(tmb);

            resultado.setText(Float.toString(tmb).replaceFirst("[\\s\\S]{0,2}$", ""));

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("principal");
    }

    @FXML
    void initialize() {
        assert actividad != null
                : "fx:id=\"actividad\" was not injected: check your FXML file 'calculadoraCalorias.fxml'.";
        assert altura != null : "fx:id=\"altura\" was not injected: check your FXML file 'calculadoraCalorias.fxml'.";
        assert edad != null : "fx:id=\"edad\" was not injected: check your FXML file 'calculadoraCalorias.fxml'.";
        assert genero != null : "fx:id=\"genero\" was not injected: check your FXML file 'calculadoraCalorias.fxml'.";
        assert kilogramos != null
                : "fx:id=\"kilogramos\" was not injected: check your FXML file 'calculadoraCalorias.fxml'.";
        assert resultado != null
                : "fx:id=\"resultado\" was not injected: check your FXML file 'calculadoraCalorias.fxml'.";
        assert volver != null : "fx:id=\"volver\" was not injected: check your FXML file 'calculadoraCalorias.fxml'.";
        genero.getItems().add("Hombre");
        genero.getItems().add("Mujer");
        actividad.getItems().add("Sedentario");
        actividad.getItems().add("Poca actividad fisica (ejercicio de 1 a 3 veces por semana)");
        actividad.getItems().add("Actividad moderada (ejercicio de 3 a 5 veces por semana)");
        actividad.getItems().add("Actividad intensa (ejercicio de 6 a 7 veces por semana)");
        actividad.getItems().add("Athleta profesional (entrenamientos de más de 4 horas diarias)");

    }

}
