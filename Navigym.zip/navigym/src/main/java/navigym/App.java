package navigym;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.shape.Rectangle;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * JavaFX App
 */

public class App extends Application {

    public static Connection conectar() {

        try {

            // Conexión con la BD

            Connection con = DriverManager.getConnection("jdbc:mysql://172.17.0.2:3306/navigym",
                    "root", "admini");

            // Connection con =
            // DriverManager.getConnection("jdbc:mysql://localhost:3306/navigym",
            // "root", "2004");

            return con;

        } catch (SQLException e) {

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("");
            error.setHeaderText("!! ERROR ¡¡");
            error.setContentText("Error en la bd: " + e.getErrorCode() + "-" + e.getMessage());
            error.showAndWait();

            return null;

        }

    }

    static Connection con;

    static ArrayList<administrador> administradores = new ArrayList<administrador>();
    static ArrayList<usuario> usuarios = new ArrayList<usuario>();
    static ArrayList<profesor> profesores = new ArrayList<profesor>();
    static ArrayList<clase> clasesDisponibles = new ArrayList<clase>();
    static ArrayList<clase> clasesReservadas = new ArrayList<clase>();
    static ArrayList<usuarioApuntanClase> usuarioApuntanClasesArray = new ArrayList<usuarioApuntanClase>();

    private static void volcarInformacion() throws SQLException {

        try {

            con = App.conectar();
            Statement st = con.createStatement();

            // PARA ADMINISTRADORES

            ResultSet rs1 = st.executeQuery("SELECT * FROM administrador");

            while (rs1.next()) {

                administradores.add(new administrador(rs1.getString("dni"),
                        rs1.getString("nombre"),
                        rs1.getString("apellidos"),
                        rs1.getInt("numeroTelefono"),
                        rs1.getString("contraseña"),
                        rs1.getString("fechaNacimiento")));

            }

            // PARA USUARIOS

            ResultSet rs2 = st.executeQuery("SELECT * FROM usuarios");

            while (rs2.next()) {

                usuarios.add(new usuario(rs2.getString("dni"),
                        rs2.getString("nombre"),
                        rs2.getString("apellidos"),
                        rs2.getInt("numeroTelefono"),
                        rs2.getString("contraseña"),
                        rs2.getString("fechaNacimiento")));

            }

            // PARA PROFESORES

            ResultSet rs3 = st.executeQuery("SELECT * FROM profesor");

            while (rs3.next()) {

                profesores.add(new profesor(rs3.getString("dni"),
                        rs3.getString("nombre"),
                        rs3.getString("apellidos"),
                        rs3.getInt("numeroTelefono"),
                        rs3.getString("fechaNacimiento")));

            }

            // PARA CLASES DISPONIBLES

            ResultSet rs4 = st.executeQuery("SELECT * FROM clases");

            while (rs4.next()) {

                clasesDisponibles
                        .add(new clase(rs4.getInt("id"), rs4.getString("nombre"), rs4.getInt("capacidadActual"),
                                rs4.getInt("capacidad"), rs4.getString("fecha"), rs4.getString("dni")));

            }

            // PARA CLASES RESERVADAS

            ResultSet rs5 = st.executeQuery("SELECT * FROM usuarioApuntanClases");

            while (rs5.next()) {

                for (int i = 0; i < clasesDisponibles.size(); i++) {

                    if (clasesDisponibles.get(i).getId() == rs5.getInt("id")) {

                        clasesReservadas.add(clasesDisponibles.get(i));

                    }

                }

            }

            // PARA CLASES usuarioApuntanClase

            ResultSet rs6 = st.executeQuery("SELECT * FROM usuarioApuntanClases");

            while (rs6.next()) {

                usuarioApuntanClasesArray.add(new usuarioApuntanClase(rs6.getString("dni"), rs6.getInt("id")));

            }

        } catch (Exception e) {

            Alert errorImportarInformacion = new Alert(Alert.AlertType.ERROR);
            errorImportarInformacion.setTitle("!! ERROR EN TRAER INFORMACION DE LA BD ¡¡");
            errorImportarInformacion.setContentText(e.getMessage());
            errorImportarInformacion.showAndWait();

        }

    }

    private static Scene scene;
    private static Stage stage;

    @Override
    public void start(Stage stage1) throws IOException, SQLException {
        App.volcarInformacion();
        stage = stage1;
        scene = new Scene(loadFXML("login"));
        stage.setScene(scene);

        stage.show();
        
        Rectangle2D screenBounds = Screen.getPrimary().getPrimary().getVisualBounds();
        stage.setX((screenBounds.getWidth() - stage.getWidth()) / 2);
        stage.setY((screenBounds.getHeight() - stage.getHeight()) / 2);
    }

    static void setRoot(String fxml) throws IOException {
        scene = new Scene(loadFXML(fxml));
        stage.setScene(scene);
        stage.show();

        Rectangle2D screenBounds = Screen.getPrimary().getPrimary().getVisualBounds();
        stage.setX((screenBounds.getWidth() - stage.getWidth()) / 2);
        stage.setY((screenBounds.getHeight() - stage.getHeight()) / 2);
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}