package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class EliminarProfesorController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView tablaProfesor;
    @FXML
    private TableColumn apellidosCL;
    @FXML
    private TableColumn dniCL;
    @FXML
    private TableColumn fechaNacimientoCL;
    @FXML
    private TableColumn nombreCL;
    @FXML
    private TableColumn telefonoCL;
    ObservableList<profesor> profesoresOL;

    private void inicializarTablaClases() {

        dniCL.setCellValueFactory(new PropertyValueFactory<profesor, String>("dni"));
        nombreCL.setCellValueFactory(new PropertyValueFactory<profesor, String>("nombre"));
        apellidosCL.setCellValueFactory(new PropertyValueFactory<profesor, String>("apellidos"));
        telefonoCL.setCellValueFactory(new PropertyValueFactory<profesor, Integer>("numeroTelefono"));
        fechaNacimientoCL.setCellValueFactory(new PropertyValueFactory<profesor, String>("fechaNacimiento"));

        profesoresOL = FXCollections.observableArrayList();
        tablaProfesor.setItems(profesoresOL);

    }

    profesor profesorSeleccionada = null;

    @FXML
    void eliminarProfesor(ActionEvent event) {

        if (profesoresOL.size() != 0) {

            profesorSeleccionada = profesoresOL.get(tablaProfesor.getSelectionModel().getFocusedIndex());

            try {

                String SQL = "Delete from profesor where dni = '"
                        + profesorSeleccionada.getDni() + "'";
                Statement st = App.con.createStatement();
                st.executeUpdate(SQL);

            } catch (Exception e) {
                
                System.out.println(e.getMessage());

            }

            for (int i = 0; i < profesoresOL.size(); i++) {

                if (profesorSeleccionada.getDni() == profesoresOL.get(i).getDni()) {

                    profesoresOL.remove(i);

                }

            }

            for (int i = 0; i < App.profesores.size(); i++) {

                if (profesorSeleccionada.getDni() == App.profesores.get(i).getDni()) {

                    App.profesores.remove(i);

                }

            }

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("admin");
    }

    @FXML
    void initialize() {
        assert apellidosCL != null : "fx:id=\"apellidosCL\" was not injected: check your FXML file 'eliminarProfesor.fxml'.";
        assert dniCL != null : "fx:id=\"dniCL\" was not injected: check your FXML file 'eliminarProfesor.fxml'.";
        assert fechaNacimientoCL != null : "fx:id=\"fechaNacimientoCL\" was not injected: check your FXML file 'eliminarProfesor.fxml'.";
        assert nombreCL != null : "fx:id=\"nombreCL\" was not injected: check your FXML file 'eliminarProfesor.fxml'.";
        assert tablaProfesor != null : "fx:id=\"tablaProfesor\" was not injected: check your FXML file 'eliminarProfesor.fxml'.";
        assert telefonoCL != null : "fx:id=\"telefonoCL\" was not injected: check your FXML file 'eliminarProfesor.fxml'.";

        inicializarTablaClases();

        for (int i = 0; i < App.profesores.size(); i++) {

            profesoresOL.add(App.profesores.get(i));

        }

    }

}
