package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class ClasesReservadasController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button botonReservar;

    @FXML
    private TableView tablaClases;
    @FXML
    private TableColumn idCL;
    @FXML
    private TableColumn claseCL;
    @FXML
    private TableColumn fechaCL;
    @FXML
    private TableColumn capacidadActualCL;
    @FXML
    private TableColumn capacidadCL;
    ObservableList<clase> clases;

    clase claseSeleccionada = null;

    @FXML
    void cancelar(ActionEvent event) {

        if (clases.size() != 0) {

            claseSeleccionada = clases.get(tablaClases.getSelectionModel().getFocusedIndex());

        }

        if (claseSeleccionada != null) {

            for (int i = 0; i < App.clasesReservadas.size(); i++) {

                if (App.clasesReservadas.get(i).getId() == claseSeleccionada.getId()) {

                    App.clasesReservadas.remove(i);

                }

            }

            try {

                String SQL = "Delete from usuarioApuntanClases where id= " + claseSeleccionada.getId();
                Statement st = App.con.createStatement();
                int n = st.executeUpdate(SQL);

                PreparedStatement ps1;
                String sql1 = "update clases set capacidadActual = capacidadActual - 1 where id = ?";
                ps1 = App.con.prepareStatement(sql1);
                ps1.setInt(1, claseSeleccionada.getId());
                ps1.executeUpdate();

                if (n >= 0) {

                    Alert claseEliminada = new Alert(Alert.AlertType.CONFIRMATION);
                    claseEliminada.setTitle("");
                    claseEliminada.setContentText("Clase cancelada");
                    claseEliminada.showAndWait();

                }

            } catch (Exception e) {

                System.out.println(e.getMessage());

            } finally {

                claseSeleccionada = null;

            }

            clases.clear();

            try {

                App.con = App.conectar();
                Statement st = App.con.createStatement();
                ResultSet rs1 = st.executeQuery("SELECT c.id, c.nombre, c.capacidadActual, c.capacidad, c.fecha, c.dni FROM usuarioApuntanClases u INNER JOIN clases c USING (id) WHERE u.dni = '" + LoginController.usuarioIniciado.getDni() + "'");
    
                while (rs1.next()) {
    
                    clases.add(new clase(rs1.getInt("id"), rs1.getString("nombre"), rs1.getInt("capacidadActual"),
                            rs1.getInt("capacidad"), rs1.getString("fecha"), rs1.getString("dni")));
    
                }
    
            } catch (Exception e) {
    
                System.out.println("ERROR - " + e.getMessage());
    
            }

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("principal");
    }

    private void inicializarTablaClases() {

        idCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("id"));
        claseCL.setCellValueFactory(new PropertyValueFactory<clase, String>("nombre"));
        fechaCL.setCellValueFactory(new PropertyValueFactory<clase, String>("fecha"));
        capacidadActualCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("capacidadActual"));
        capacidadCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("capacidad"));

        clases = FXCollections.observableArrayList();
        tablaClases.setItems(clases);

    }

    @FXML
    void initialize() {
        assert botonReservar != null
                : "fx:id=\"botonReservar\" was not injected: check your FXML file 'clasesReservadas.fxml'.";
        assert capacidadActualCL != null
                : "fx:id=\"capacidadActualCL\" was not injected: check your FXML file 'clasesReservadas.fxml'.";
        assert capacidadCL != null
                : "fx:id=\"capacidadCL\" was not injected: check your FXML file 'clasesReservadas.fxml'.";
        assert claseCL != null : "fx:id=\"claseCL\" was not injected: check your FXML file 'clasesReservadas.fxml'.";
        assert fechaCL != null : "fx:id=\"fechaCL\" was not injected: check your FXML file 'clasesReservadas.fxml'.";
        assert idCL != null : "fx:id=\"idCL\" was not injected: check your FXML file 'clasesReservadas.fxml'.";
        assert tablaClases != null
                : "fx:id=\"tablaClases\" was not injected: check your FXML file 'clasesReservadas.fxml'.";
        inicializarTablaClases();

        try {

            App.con = App.conectar();
            Statement st = App.con.createStatement();
            ResultSet rs1 = st.executeQuery("SELECT c.id, c.nombre, c.capacidadActual, c.capacidad, c.fecha, c.dni FROM usuarioApuntanClases u INNER JOIN clases c USING (id) WHERE u.dni = '" + LoginController.usuarioIniciado.getDni() + "'");

            while (rs1.next()) {

                clases.add(new clase(rs1.getInt("id"), rs1.getString("nombre"), rs1.getInt("capacidadActual"),
                        rs1.getInt("capacidad"), rs1.getString("fecha"), rs1.getString("dni")));

            }

        } catch (Exception e) {

            System.out.println("ERROR - " + e.getMessage());

        }

    }

}
