package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;

public class NoticiasController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<mensaje> tablaMensajes;
    @FXML
    private TableColumn asuntoCL;
    @FXML
    private TableColumn mensajeCL;
    @FXML
    private TableColumn fechaCL;
    ObservableList<mensaje> mensajes;

    mensaje mensajeSeleccionada = null;

    @FXML
    void eliminarMensaje(ActionEvent event) {

        if (mensajes.size() != 0) {

            mensajeSeleccionada = mensajes.get(tablaMensajes.getSelectionModel().getFocusedIndex());

            try {

                String SQL = "Delete from mensajePerteneceUsuario where dni = '"
                        + LoginController.usuarioIniciado.getDni() + "' AND id = " + mensajeSeleccionada.getId();
                Statement st = App.con.createStatement();
                st.executeUpdate(SQL);

            } catch (Exception e) {
                
                System.out.println(e.getMessage());

            }

            for (int i = 0; i < mensajes.size(); i++) {

                if (mensajeSeleccionada.getId() == mensajes.get(i).getId()) {

                    mensajes.remove(i);

                }

            }

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("principal");
    }

    private void inicializarTablaMensajes() {

        asuntoCL.setCellValueFactory(new PropertyValueFactory<mensaje, String>("Asunto"));
        mensajeCL.setCellValueFactory(new PropertyValueFactory<mensaje, String>("Mensaje"));
        fechaCL.setCellValueFactory(new PropertyValueFactory<mensaje, String>("Fecha"));

        mensajes = FXCollections.observableArrayList();
        tablaMensajes.setItems(mensajes);

    }

    // ArrayList<mensaje> mensajesArray = new ArrayList<mensaje>();

    @FXML
    void initialize() {
        assert tablaMensajes != null
                : "fx:id=\"tablaMensajes\" was not injected: check your FXML file 'noticias.fxml'.";
        assert asuntoCL != null : "fx:id=\"asuntoCL\" was not injected: check your FXML file 'noticias.fxml'.";
        assert mensajeCL != null : "fx:id=\"mensajeCL\" was not injected: check your FXML file 'noticias.fxml'.";
        assert fechaCL != null : "fx:id=\"fechaCL\" was not injected: check your FXML file 'noticias.fxml'.";
        this.inicializarTablaMensajes();

        try {

            App.con = App.conectar();
            Statement st = App.con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM mensajePerteneceUsuario WHERE dni = '"
                    + LoginController.usuarioIniciado.getDni() + "'");

            while (rs.next()) {

                Statement st1 = App.con.createStatement();
                ResultSet rs1 = st1.executeQuery("SELECT * FROM mensaje WHERE id = " + rs.getInt("id"));
                rs1.next();
                mensajes.add(new mensaje(rs1.getInt("id"), rs1.getString("asunto"), rs1.getString("mensaje"),
                        rs1.getString("fecha")));

            }

        } catch (Exception e) {

            System.out.println("ERROR - " + e.getMessage());

        }

    }

}
