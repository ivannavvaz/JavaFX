package navigym;

public class mensaje {

    // VARIABLES

    private int id;
    private String asunto;
    private String mensaje;
    private String fecha;

    // CONSTRUCTORES

    public mensaje(int id, String asunto, String mensaje, String fecha) {
        this.id = id;
        this.asunto = asunto;
        this.mensaje = mensaje;
        this.fecha = fecha;
    }

    // GETTERS Y SETTERS
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getAsunto() {
        return asunto;
    }
    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }
    public String getMensaje() {
        return mensaje;
    }
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

}
