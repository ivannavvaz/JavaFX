package navigym;

public class administrador extends usuariosSistema {

    public administrador(String dni, String nombre, String apellidos, int numeroTelefono, String contrasena,
            String fechaNacimiento) {
        
                super(dni, nombre, apellidos, numeroTelefono, contrasena, fechaNacimiento);

    }

}
