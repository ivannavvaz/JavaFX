package navigym;

public class clase {

    // VARIABLES

    private Integer id;
    private String nombre;
    private Integer capacidadActual;
    private Integer capacidad;
    private String fecha;
    private String dni;

    // CONSTRUCTORES
    
    public clase(int id, String nombre, Integer capacidadActual, Integer capacidad, String fecha, String dni) {
        this.id = id;
        this.nombre = nombre;
        this.capacidadActual = capacidadActual;
        this.capacidad = capacidad;
        this.fecha = fecha;
        this.dni = dni;
    }

    // GETTERS Y SETTERS

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public Integer getCapacidadActual() {
        return capacidadActual;
    }
    public void setCapacidadActual(Integer capacidadActual) {
        this.capacidadActual = capacidadActual;
    }
    public Integer getCapacidad() {
        return capacidad;
    }
    public void setCapacidad(Integer capacidad) {
        this.capacidad = capacidad;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getDni() {
        return dni;
    }
    public void setDni(String dni) {
        this.dni = dni;
    }
    
}
