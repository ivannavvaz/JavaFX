package navigym;

public class usuario extends usuariosSistema {

    public usuario(String dni, String nombre, String apellidos, int numeroTelefono, String contrasena,
            String fechaNacimiento) {
        
                super(dni, nombre, apellidos, numeroTelefono, contrasena, fechaNacimiento);

    }

}