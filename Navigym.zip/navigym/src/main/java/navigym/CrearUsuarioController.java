package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class CrearUsuarioController {

    @FXML
    private CheckBox administrador;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField apellidos;

    @FXML
    private TextField contrasena;

    @FXML
    private TextField dni;

    @FXML
    private DatePicker fecha;

    @FXML
    private TextField nombre;

    @FXML
    private TextField numeroTelefono;

    @FXML
    void crearProfesor(ActionEvent event) {

        if (dni.getText().equals("") || nombre.getText().equals("") || apellidos.getText().equals("")
                || numeroTelefono.getText().equals("") || contrasena.getText().equals("") || fecha.getValue() == null) {

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("");
            error.setHeaderText("!! ERROR ¡¡");
            error.setContentText("Debes rellenar todos los campos");
            error.showAndWait();

        } else {

            Pattern regex = Pattern.compile("[^A-Za-z0-9]");
            Pattern regex2 = Pattern.compile("[^0-9]");

            Matcher matcher = regex.matcher(dni.getText());
            Matcher matcher2 = regex.matcher(nombre.getText());
            Matcher matcher3 = regex.matcher(apellidos.getText());
            Matcher matcher4 = regex2.matcher(numeroTelefono.getText());

            Alert error = new Alert(Alert.AlertType.ERROR);

            if (matcher.find()) {

                error.setTitle("");
                error.setHeaderText("!! ERROR ¡¡");
                error.setContentText("El dni solo puede contener letras y numeros");
                error.showAndWait();

            } else if (matcher2.find()) {

                error.setTitle("");
                error.setHeaderText("!! ERROR ¡¡");
                error.setContentText("El nombre solo puede contener letras y numeros");
                error.showAndWait();

            } else if (matcher3.find()) {

                error.setTitle("");
                error.setHeaderText("!! ERROR ¡¡");
                error.setContentText("Los apellidos solo puede contener letras y numeros");
                error.showAndWait();

            } else if (matcher4.find()) {

                error.setTitle("");
                error.setHeaderText("!! ERROR ¡¡");
                error.setContentText("El numero de telefono solo puede contener numeros");
                error.showAndWait();

            } else {

                try {

                    String sql;
                    PreparedStatement ps;

                    App.con = App.conectar();
                    Statement st = App.con.createStatement();

                    if (administrador.isSelected()) {

                        sql = "insert into administrador(dni, nombre, apellidos, numeroTelefono, contraseña, fechaNacimiento) values(?,?,?,?,?,?)";
                        ps = App.con.prepareStatement(sql);

                        ps.setString(1, dni.getText());
                        ps.setString(2, nombre.getText());
                        ps.setString(3, apellidos.getText());
                        ps.setInt(4, Integer.parseInt(numeroTelefono.getText()));
                        ps.setString(5, contrasena.getText());
                        ps.setString(6, fecha.getValue().toString());
                        ps.executeUpdate();

                        App.administradores.add(new administrador(dni.getText(), nombre.getText(), apellidos.getText(),
                                Integer.parseInt(numeroTelefono.getText()), contrasena.getText(),
                                fecha.getValue().toString()));

                    } else {

                        sql = "insert into usuarios(dni, nombre, apellidos, numeroTelefono, contraseña, fechaNacimiento) values(?,?,?,?,?,?)";
                        ps = App.con.prepareStatement(sql);

                        ps.setString(1, dni.getText());
                        ps.setString(2, nombre.getText());
                        ps.setString(3, apellidos.getText());
                        ps.setInt(4, Integer.parseInt(numeroTelefono.getText()));
                        ps.setString(5, contrasena.getText());
                        ps.setString(6, fecha.getValue().toString());
                        ps.executeUpdate();

                        App.usuarios.add(new usuario(dni.getText(), nombre.getText(), apellidos.getText(),
                                Integer.parseInt(numeroTelefono.getText()), contrasena.getText(),
                                fecha.getValue().toString()));

                    }

                    Alert usuarioCreado = new Alert(Alert.AlertType.CONFIRMATION);
                    usuarioCreado.setTitle("");
                    usuarioCreado.setHeaderText("Usuario creado");
                    usuarioCreado.setContentText(
                            "Usuario: " + nombre.getText() + " " + apellidos.getText() + " - DNI: " + dni.getText());
                    usuarioCreado.showAndWait();

                    administrador.setSelected(false);
                    dni.setText("");
                    nombre.setText("");
                    apellidos.setText("");
                    numeroTelefono.setText("");
                    contrasena.setText("");
                    fecha.setValue(null);

                } catch (Exception e) {

                    error.setTitle("");
                    error.setHeaderText("!! ERROR ¡¡");
                    error.setContentText(e.getMessage());
                    error.showAndWait();

                }

            }

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("admin");
    }

    @FXML
    void initialize() {
        assert administrador != null
                : "fx:id=\"administrador\" was not injected: check your FXML file 'crearUsuario.fxml'.";
        assert apellidos != null : "fx:id=\"apellidos\" was not injected: check your FXML file 'crearUsuario.fxml'.";
        assert contrasena != null : "fx:id=\"contrasena\" was not injected: check your FXML file 'crearUsuario.fxml'.";
        assert dni != null : "fx:id=\"dni\" was not injected: check your FXML file 'crearUsuario.fxml'.";
        assert fecha != null : "fx:id=\"fecha\" was not injected: check your FXML file 'crearUsuario.fxml'.";
        assert nombre != null : "fx:id=\"nombre\" was not injected: check your FXML file 'crearUsuario.fxml'.";
        assert numeroTelefono != null
                : "fx:id=\"numeroTelefono\" was not injected: check your FXML file 'crearUsuario.fxml'.";

    }

}
