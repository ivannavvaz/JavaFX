package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;

public class CrearClasesController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Spinner<Integer> capacidad;

    @FXML
    private DatePicker fecha;

    @FXML
    private ChoiceBox<String> hora;

    @FXML
    private ChoiceBox<String> nombre;

    @FXML
    private ChoiceBox<String> profesor;

    @FXML
    void fechaSeleccionada(MouseEvent event) {
        profesor.getItems().clear();
    }

    @FXML
    void horaSeleccionada(MouseEvent event) {
        profesor.getItems().clear();
    }

    @FXML
    void crearClase(ActionEvent event) {

        if (fecha.getValue() != null && hora.getValue() != null && nombre.getValue() != null
                && profesor.getValue() != null) {

            String sql;
            PreparedStatement ps;

            String[] dniPartes = profesor.getValue().split("\\(");

            try {

                App.con = App.conectar();
                Statement st = App.con.createStatement();

                sql = "insert into clases(nombre, capacidad, fecha, dni) values(?,?,?,?)";
                ps = App.con.prepareStatement(sql);

                ps.setString(1, nombre.getValue());
                ps.setInt(2, capacidad.getValue());
                ps.setString(3, fecha.getValue() + " " + hora.getValue() + ":00");
                ps.setString(4, dniPartes[1].substring(0, dniPartes[1].length() - 1));
                ps.executeUpdate();

                int id = App.clasesDisponibles.get(App.clasesDisponibles.size() - 1).getId() + 1;

                App.clasesDisponibles.add(new clase(id, nombre.getValue(), 0, capacidad.getValue(),
                        (fecha.getValue() + " " + hora.getValue() + ":00").toString(),
                        dniPartes[1].substring(0, dniPartes[1].length() - 1)));

                Alert error = new Alert(Alert.AlertType.CONFIRMATION);
                error.setTitle("");
                error.setHeaderText("Clase creada con exito");
                error.setContentText(
                        nombre.getValue() + " - " + (fecha.getValue() + " " + hora.getValue() + ":00").toString());
                error.showAndWait();

                nombre.setValue(null);
                capacidad.getValueFactory().setValue(10);
                nombre.setValue(null);
                fecha.setValue(null);
                hora.setValue(null);
                profesor.setValue(null);

            } catch (Exception e) {

                System.out.println("ERROR - " + e.getMessage());

            }

        } else {

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("");
            error.setHeaderText("!! ERROR ¡¡");
            error.setContentText("ERROR - Debes rellenar todos los campos");
            error.showAndWait();

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("admin");
    }

    @FXML
    void initialize() {
        assert capacidad != null : "fx:id=\"capacidad\" was not injected: check your FXML file 'crearClases.fxml'.";
        assert fecha != null : "fx:id=\"fecha\" was not injected: check your FXML file 'crearClases.fxml'.";
        assert hora != null : "fx:id=\"hora\" was not injected: check your FXML file 'crearClases.fxml'.";
        assert nombre != null : "fx:id=\"nombre\" was not injected: check your FXML file 'crearClases.fxml'.";
        assert profesor != null : "fx:id=\"profesor\" was not injected: check your FXML file 'crearClases.fxml'.";
        hora.getItems().add("08:00");
        hora.getItems().add("09:00");
        hora.getItems().add("10:00");
        hora.getItems().add("17:00");
        hora.getItems().add("18:00");
        hora.getItems().add("19:00");
        nombre.getItems().add("Bodypump");
        nombre.getItems().add("Bodycombat");
        nombre.getItems().add("Yoga");
        nombre.getItems().add("Spinning");
        nombre.getItems().add("Crossfit");
        SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(10, 50);
        capacidad.setValueFactory(valueFactory);

        profesor.setOnShowing(e -> {

            profesor.getItems().clear();

            boolean anadir = false;

            if (fecha.getValue() != null && hora.getValue() != null) {

                for (int i = 0; i < App.profesores.size(); i++) {

                    anadir = true;

                    for (int j = 0; j < App.clasesDisponibles.size(); j++) {

                        if (App.clasesDisponibles.get(j).getFecha()
                                .equals(fecha.getValue() + " " + hora.getValue() + ":00")
                                && App.clasesDisponibles.get(j).getDni().equals(App.profesores.get(i).getDni())) {

                            anadir = false;

                        }

                    }

                    if (anadir) {

                        profesor.getItems().add(App.profesores.get(i).getNombre() + " "
                                + App.profesores.get(i).getApellidos() + " (" + App.profesores.get(i).getDni() + ")");

                    }

                }

            }

        });

    }

}
