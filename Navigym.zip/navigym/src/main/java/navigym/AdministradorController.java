package navigym;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class AdministradorController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView clases;


    @FXML
    void crearProfesor(MouseEvent event) throws IOException {
        App.setRoot("crearProfesor");
    }

    @FXML
    void crearUsuario(MouseEvent event) throws IOException {
        App.setRoot("crearUsuario");
    }

    @FXML
    void crearClases(MouseEvent event) throws IOException {
        App.setRoot("crearClases");
    }

    @FXML
    void enviarMensaje(MouseEvent event) throws IOException {
        App.setRoot("enviarMensaje");
    }

    @FXML
    void salir(MouseEvent event) throws IOException {
        App.setRoot("login");
    }

    @FXML
    void verSugerencias(MouseEvent event) throws IOException {
        App.setRoot("verSugerencias");
    }

    @FXML
    void eliminarClase(MouseEvent event) throws IOException {
        App.setRoot("eliminarClase");
    }

    @FXML
    void eliminarProfesor(MouseEvent event) throws IOException {
        App.setRoot("eliminarProfesor");
    }

    @FXML
    void eliminarUsuario(MouseEvent event) throws IOException {
        App.setRoot("eliminarUsuario");
    }

    @FXML
    void initialize() {
        assert clases != null : "fx:id=\"clases\" was not injected: check your FXML file 'admin.fxml'.";

    }

}
