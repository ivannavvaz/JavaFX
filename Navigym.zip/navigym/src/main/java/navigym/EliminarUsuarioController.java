package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class EliminarUsuarioController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView tablaUsuario;
    @FXML
    private TableColumn apellidosCL;
    @FXML
    private TableColumn contrasenaCL;
    @FXML
    private TableColumn dniCL;
    @FXML
    private TableColumn fechaNacimientoCL;
    @FXML
    private TableColumn nombreCL;
    @FXML
    private TableColumn telefonoCL;
    ObservableList<usuario> usuarios;

    private void inicializarTablaClases() {

        dniCL.setCellValueFactory(new PropertyValueFactory<usuario, String>("dni"));
        nombreCL.setCellValueFactory(new PropertyValueFactory<usuario, String>("nombre"));
        apellidosCL.setCellValueFactory(new PropertyValueFactory<usuario, String>("apellidos"));
        telefonoCL.setCellValueFactory(new PropertyValueFactory<usuario, Integer>("numeroTelefono"));
        contrasenaCL.setCellValueFactory(new PropertyValueFactory<usuario, String>("contrasena"));
        fechaNacimientoCL.setCellValueFactory(new PropertyValueFactory<usuario, String>("fechaNacimiento"));

        usuarios = FXCollections.observableArrayList();
        tablaUsuario.setItems(usuarios);

    }

    usuario usuarioSeleccionado = null;

    @FXML
    void eliminarUsuario(ActionEvent event) {

        if (usuarios.size() != 0) {

            usuarioSeleccionado = usuarios.get(tablaUsuario.getSelectionModel().getFocusedIndex());

            try {

                App.con = App.conectar();
                Statement st1 = App.con.createStatement();
                ResultSet rs1 = st1.executeQuery(
                        "SELECT c.id FROM usuarioApuntanClases u INNER JOIN clases c USING (id) WHERE u.dni = '"
                                + usuarioSeleccionado.getDni() + "'");

                while (rs1.next()) {

                    PreparedStatement ps1;
                    String sql1 = "update clases set capacidadActual = capacidadActual - 1 where id = ?";
                    ps1 = App.con.prepareStatement(sql1);
                    ps1.setInt(1, rs1.getInt("id"));
                    ps1.executeUpdate();

                }

                String SQL = "Delete from usuarios where dni = '"
                        + usuarioSeleccionado.getDni() + "'";
                Statement st = App.con.createStatement();
                st.executeUpdate(SQL);

            } catch (Exception e) {

                System.out.println(e.getMessage());

            }

            for (int i = 0; i < usuarios.size(); i++) {

                if (usuarioSeleccionado.getDni() == usuarios.get(i).getDni()) {

                    usuarios.remove(i);

                }

            }

            for (int i = 0; i < App.usuarios.size(); i++) {

                if (usuarioSeleccionado.getDni() == App.usuarios.get(i).getDni()) {

                    App.usuarios.remove(i);

                }

            }

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("admin");
    }

    @FXML
    void initialize() {
        assert apellidosCL != null
                : "fx:id=\"apellidosCL\" was not injected: check your FXML file 'eliminarUsuario.fxml'.";
        assert contrasenaCL != null
                : "fx:id=\"contrasenaCL\" was not injected: check your FXML file 'eliminarUsuario.fxml'.";
        assert dniCL != null : "fx:id=\"dniCL\" was not injected: check your FXML file 'eliminarUsuario.fxml'.";
        assert fechaNacimientoCL != null
                : "fx:id=\"fechaNacimientoCL\" was not injected: check your FXML file 'eliminarUsuario.fxml'.";
        assert nombreCL != null : "fx:id=\"nombreCL\" was not injected: check your FXML file 'eliminarUsuario.fxml'.";
        assert tablaUsuario != null
                : "fx:id=\"tablaProfesor\" was not injected: check your FXML file 'eliminarUsuario.fxml'.";
        assert telefonoCL != null
                : "fx:id=\"telefonoCL\" was not injected: check your FXML file 'eliminarUsuario.fxml'.";

        inicializarTablaClases();

        for (int i = 0; i < App.usuarios.size(); i++) {

            usuarios.add(App.usuarios.get(i));

        }

    }

}
