package navigym;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class CalculadoraRMController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField kilos;

    @FXML
    private TextField porcentaje40;

    @FXML
    private TextField porcentaje45;

    @FXML
    private TextField porcentaje50;

    @FXML
    private TextField porcentaje55;

    @FXML
    private TextField porcentaje60;

    @FXML
    private TextField porcentaje65;

    @FXML
    private TextField porcentaje70;

    @FXML
    private TextField porcentaje75;

    @FXML
    private TextField porcentaje80;

    @FXML
    private TextField porcentaje85;

    @FXML
    private TextField porcentaje90;

    @FXML
    private TextField porcentaje95;

    @FXML
    private TextField repeticionMaxima;

    @FXML
    private TextField repeticiones;

    @FXML
    void calcular(ActionEvent event) {

        try {

            float kilo = Float.parseFloat(kilos.getText());
            float reps = Float.parseFloat(repeticiones.getText());

            double repeticionMaximaResultado = Math.round(kilo / (1.0278 - 0.0278 * reps));

            repeticionMaxima.setText(Double.toString(repeticionMaximaResultado).replaceFirst("[\\s\\S]{0,2}$", ""));

            porcentaje40.setText(String.valueOf(Math.round((double) (40.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje45.setText(String.valueOf(Math.round((double) (45.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje50.setText(String.valueOf(Math.round((double) (50.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje55.setText(String.valueOf(Math.round((double) (55.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje60.setText(String.valueOf(Math.round((double) (60.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje65.setText(String.valueOf(Math.round((double) (65.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje70.setText(String.valueOf(Math.round((double) (70.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje75.setText(String.valueOf(Math.round((double) (75.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje80.setText(String.valueOf(Math.round((double) (80.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje85.setText(String.valueOf(Math.round((double) (85.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje90.setText(String.valueOf(Math.round((double) (90.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));
            porcentaje95.setText(String.valueOf(Math.round((double) (95.0 / 100.0) * Double.parseDouble(repeticionMaxima.getText()))));

        } catch (Exception e) {
        
            kilos.setText("");
            repeticiones.setText("");

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("");
            error.setHeaderText("!! ERROR ¡¡");
            error.setContentText("ERROR - Debes poner numeros");
            error.showAndWait();

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("principal");
    }

    @FXML
    void initialize() {
        assert kilos != null : "fx:id=\"kilos\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje40 != null
                : "fx:id=\"porcentaje40\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje45 != null
                : "fx:id=\"porcentaje45\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje50 != null
                : "fx:id=\"porcentaje50\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje55 != null
                : "fx:id=\"porcentaje55\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje60 != null
                : "fx:id=\"porcentaje60\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje65 != null
                : "fx:id=\"porcentaje65\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje70 != null
                : "fx:id=\"porcentaje70\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje75 != null
                : "fx:id=\"porcentaje75\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje80 != null
                : "fx:id=\"porcentaje80\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje85 != null
                : "fx:id=\"porcentaje85\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje90 != null
                : "fx:id=\"porcentaje90\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert porcentaje95 != null
                : "fx:id=\"porcentaje95\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert repeticionMaxima != null
                : "fx:id=\"repeticionMaxima\" was not injected: check your FXML file 'calculadoraRM.fxml'.";
        assert repeticiones != null
                : "fx:id=\"repeticiones\" was not injected: check your FXML file 'calculadoraRM.fxml'.";

    }

}
