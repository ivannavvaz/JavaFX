package navigym;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PrincipalController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void calculadoraCalorias(MouseEvent event) throws IOException {
        App.setRoot("calculadoraCalorias");
    }

    @FXML
    void calculadoraRM(MouseEvent event) throws IOException {
        App.setRoot("calculadoraRM");
    }

    @FXML
    void horario(MouseEvent event) throws IOException {
        App.setRoot("horario");
    }

    @FXML
    void inicio(MouseEvent event) {

    }

    @FXML
    void instagram(MouseEvent event) {

    }

    @FXML
    void noticias(MouseEvent event) throws IOException {
        App.setRoot("noticias");
    }

    @FXML
    void qr(MouseEvent event) throws IOException {
        App.setRoot("qr");
    }

    @FXML
    void reservar(MouseEvent event) throws IOException {
        App.setRoot("reserva");
    }

    @FXML
    void salir(MouseEvent event) throws IOException {
        App.setRoot("login");
    }

    @FXML
    void sugerencias(MouseEvent event) throws IOException {
        App.setRoot("sugerencias");
    }

    @FXML
    void verClases(MouseEvent event) throws IOException {
        App.setRoot("clasesReservadas");
    }

    @FXML
    void yo(MouseEvent event) {

    }

    @FXML
    void initialize() {

    }

}
