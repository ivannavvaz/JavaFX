package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class VerSugerenciasController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView tablaSugerencias;
    @FXML
    private TableColumn emisorCL;
    @FXML
    private TableColumn fechaCL;
    @FXML
    private TableColumn mensajeCL;
    ObservableList<sugerencia> sugerencias;

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("admin");
    }

    private void inicializarTablaClases() {

        fechaCL.setCellValueFactory(new PropertyValueFactory<sugerencia, String>("fecha"));
        mensajeCL.setCellValueFactory(new PropertyValueFactory<sugerencia, String>("mensaje"));
        emisorCL.setCellValueFactory(new PropertyValueFactory<sugerencia, String>("dni"));

        sugerencias = FXCollections.observableArrayList();
        tablaSugerencias.setItems(sugerencias);

    }

    sugerencia sugerenciaSeleccionada = null;

    @FXML
    void eliminarSugerencia(ActionEvent event) {

        if (sugerencias.size() != 0) {

            sugerenciaSeleccionada = sugerencias.get(tablaSugerencias.getSelectionModel().getFocusedIndex());

            try {

                String SQL = "Delete from sugerencias where id = "
                        + sugerenciaSeleccionada.getId();
                Statement st = App.con.createStatement();
                st.executeUpdate(SQL);

            } catch (Exception e) {
                
                System.out.println(e.getMessage());

            }

            for (int i = 0; i < sugerencias.size(); i++) {

                if (sugerenciaSeleccionada.getId() == sugerencias.get(i).getId()) {

                    sugerencias.remove(i);

                }

            }


        }

    }

    @FXML
    void initialize() {
        assert emisorCL != null : "fx:id=\"emisorCL\" was not injected: check your FXML file 'verSugerencias.fxml'.";
        assert fechaCL != null : "fx:id=\"fechaCL\" was not injected: check your FXML file 'verSugerencias.fxml'.";
        assert mensajeCL != null : "fx:id=\"mensajeCL\" was not injected: check your FXML file 'verSugerencias.fxml'.";
        assert tablaSugerencias != null : "fx:id=\"tablaSugerencias\" was not injected: check your FXML file 'verSugerencias.fxml'.";
        inicializarTablaClases();

        try {
        
            Connection con = App.conectar();
            Statement st = con.createStatement();
            ResultSet rs6 = st.executeQuery("SELECT * FROM sugerencias");

            while (rs6.next()) {

                sugerencias.add(new sugerencia(rs6.getInt("id"), rs6.getString("mensaje"), rs6.getString("fecha"), rs6.getString("dni")));
    
            }

        } catch (Exception e) {
            
            System.out.println(e.getMessage());

        }




    }

}
