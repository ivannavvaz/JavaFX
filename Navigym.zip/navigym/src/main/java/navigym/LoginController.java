package navigym;

import java.io.IOException;
import java.net.URL;
import java.security.Principal;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button botonValidar;

    @FXML
    private PasswordField contrasena;

    @FXML
    private TextField usuario;

    static usuariosSistema usuarioIniciado;

    @FXML
    void validar(ActionEvent event) throws IOException {

        boolean usuarioEncontrado = false; // Para ver si el usuario existe
        boolean usuarioCorrecto = false; // Para ver si a podido iniciar sesion

        if (!usuario.getText().equals("") && !contrasena.getText().equals("")) {

            for (int i = 0; i < App.usuarios.size(); i++) {

                if (App.usuarios.get(i).getDni().equals(usuario.getText())) {

                    usuarioEncontrado = true;

                }

                if (App.usuarios.get(i).getDni().toUpperCase().equals(usuario.getText().toUpperCase())
                        && App.usuarios.get(i).getContrasena().equals(contrasena.getText())) {

                    usuarioIniciado = App.usuarios.get(i);
                    App.setRoot("principal");
                    usuarioCorrecto = true;

                }

            }

            if (!usuarioCorrecto) { // Si no a iniciado sesion

                for (int i = 0; i < App.administradores.size(); i++) {

                    if (App.administradores.get(i).getDni().equals(usuario.getText())) {

                        usuarioEncontrado = true;

                    }

                    if (App.administradores.get(i).getDni().equals(usuario.getText().toUpperCase())
                            && App.administradores.get(i).getContrasena().equals(contrasena.getText())) {

                        usuarioIniciado = App.administradores.get(i);
                        App.setRoot("admin");
                        usuarioCorrecto = true;

                    }

                }

            }

            if (!usuarioCorrecto) { // Si no a iniciado sesion

                if (usuarioEncontrado) { // Si la contraseña era incorrecta y el usuario si que existe

                    Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("");
                    error.setHeaderText("!! ERROR ¡¡");
                    error.setContentText("Contraseña incorrecta");
                    error.showAndWait();

                    contrasena.setText("");

                } else { // Si no existe el usuario

                    Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("");
                    error.setHeaderText("!! ERROR ¡¡");
                    error.setContentText("Usuario no encontrado");
                    error.showAndWait();

                    usuario.setText("");
                    contrasena.setText("");

                }

            }

        }

    }

    @FXML
    void initialize() {
        assert botonValidar != null : "fx:id=\"botonValidar\" was not injected: check your FXML file 'login.fxml'.";
        assert contrasena != null : "fx:id=\"contrasena\" was not injected: check your FXML file 'login.fxml'.";
        assert usuario != null : "fx:id=\"usuario\" was not injected: check your FXML file 'login.fxml'.";

    }

}
