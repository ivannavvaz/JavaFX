package navigym;

public class usuarioApuntanClase {
    
    private String dni;
    private Integer id;

    public usuarioApuntanClase(String dni, int id) {
        this.dni = dni;
        this.id = id;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }
    public String getDni() {
        return dni;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }

}
