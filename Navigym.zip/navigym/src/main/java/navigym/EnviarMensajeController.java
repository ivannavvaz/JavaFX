package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class EnviarMensajeController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField asunto;

    @FXML
    private ChoiceBox<String> destinatario;

    @FXML
    private TextField mensaje;

    @FXML
    void enviar(ActionEvent event) {

        if (destinatario.getValue().equals(null)) {

            Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("");
                    error.setHeaderText("!! ERROR ¡¡");
                    error.setContentText("Debes reyenar el destinatario");
                    error.showAndWait();

        } else if (asunto.getText().equals("")) {

            Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("");
                    error.setHeaderText("!! ERROR ¡¡");
                    error.setContentText("Debes de poner un asunto al mensaje");
                    error.showAndWait();

        } else if (mensaje.getText().equals("")) {

            Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("");
                    error.setHeaderText("!! ERROR ¡¡");
                    error.setContentText("Debes de poner un mesnaje");
                    error.showAndWait();

        } else {

            String sql;
            PreparedStatement ps;

            try {

                // PARA CALCULAR EL DIA QUE SE ENVIA EL MENSAJE

                LocalDateTime ahora = LocalDateTime.now();
                String fechaActual;

                if (ahora.getMonthValue() < 10 && ahora.getDayOfMonth() < 10) { // Para el formato no sea 5 sino 05

                    fechaActual = ahora.getYear() + "/0" + ahora.getMonthValue() + "/0" + ahora.getDayOfMonth();

                } else if (ahora.getMonthValue() < 10) {

                    fechaActual = ahora.getYear() + "/0" + ahora.getMonthValue() + "/" + ahora.getDayOfMonth();

                } else if (ahora.getDayOfMonth() < 10) {

                    fechaActual = ahora.getYear() + "/" + ahora.getMonthValue() + "/0" + ahora.getDayOfMonth();

                } else {

                    fechaActual = ahora.getYear() + "/" + ahora.getMonthValue() + "/" + ahora.getDayOfMonth();

                }

                App.con = App.conectar();
                Statement st = App.con.createStatement();

                sql = "insert into mensaje(fecha, asunto, mensaje, dni) values(?,?,?,?)";
                ps = App.con.prepareStatement(sql);

                ps.setString(1, fechaActual);
                ps.setString(2, asunto.getText());
                ps.setString(3, mensaje.getText());
                ps.setString(4, LoginController.usuarioIniciado.getDni());
                ps.executeUpdate();

                ResultSet rs1 = st.executeQuery("SELECT MAX(id) FROM mensaje");

                rs1.next();

                int id = rs1.getInt("MAX(id)");

                if (destinatario.getValue().equals("Todos")) {

                    for (int i = 0; i < App.usuarios.size(); i++) {

                        sql = "insert into mensajePerteneceUsuario(id, dni) values(?,?)";
                        ps = App.con.prepareStatement(sql);

                        ps.setInt(1, id);
                        ps.setString(2, App.usuarios.get(i).getDni());
                        ps.executeUpdate();

                    }

                } else {

                    String[] dni = destinatario.getValue().split(" ");

                    sql = "insert into mensajePerteneceUsuario(id, dni) values(?,?)";
                    ps = App.con.prepareStatement(sql);

                    ps.setInt(1, id);
                    ps.setString(2, dni[0]);
                    ps.executeUpdate();

                }

                Alert error = new Alert(Alert.AlertType.CONFIRMATION);
                    error.setTitle("");
                    error.setHeaderText("Mensaje enviado con exito");
                    error.setContentText("Mensaje: " + mensaje.getText());
                    error.showAndWait();

                asunto.clear();
                mensaje.clear();
                destinatario.setValue(null);

            } catch (Exception e) {

                System.out.println("ERROR - " + e.getMessage());

            }

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("admin");
    }

    @FXML
    void initialize() {
        assert asunto != null : "fx:id=\"asunto\" was not injected: check your FXML file 'enviarMensaje.fxml'.";
        assert destinatario != null
                : "fx:id=\"destinatario\" was not injected: check your FXML file 'enviarMensaje.fxml'.";
        assert mensaje != null : "fx:id=\"mensaje\" was not injected: check your FXML file 'enviarMensaje.fxml'.";
        destinatario.getItems().add("Todos");
        for (int i = 0; i < App.usuarios.size(); i++) {

            destinatario.getItems().add(App.usuarios.get(i).getDni() + " (" + App.usuarios.get(i).getNombre() + " "
                    + App.usuarios.get(i).getApellidos() + ")");

        }
    }

}
