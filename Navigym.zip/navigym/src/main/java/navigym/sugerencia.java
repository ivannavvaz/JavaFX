package navigym;

public class sugerencia {

    // VARIABLES
    
    private int id;
    private String mensaje;
    private String fecha;
    private String dni;

    // CONSTRUCTORES
    
    public sugerencia(int id, String mensaje, String fecha, String dni) {
        this.id = id;
        this.mensaje = mensaje;
        this.fecha = fecha;
        this.dni = dni;
    }

    // GETTERS Y SETTERS

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getMensaje() {
        return mensaje;
    }
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getDni() {
        return dni;
    }
    public void setDni(String dni) {
        this.dni = dni;
    }

}
