package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class SugerenciasController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField sugerencia;

    @FXML
    void enviar(ActionEvent event) {

        String sql;
        PreparedStatement ps;

        if (!sugerencia.getText().equals("")) {

            try {

                App.con = App.conectar();
                Statement st = App.con.createStatement();

                // PARA CALCULAR EL DIA QUE SE ENVIA EL MENSAJE

                LocalDateTime ahora = LocalDateTime.now();
                String fechaActual;

                if (ahora.getMonthValue() < 10 && ahora.getDayOfMonth() < 10) { // Para el formato no sea 5 sino 05

                    fechaActual = ahora.getYear() + "/0" + ahora.getMonthValue() + "/0" + ahora.getDayOfMonth();

                } else if (ahora.getMonthValue() < 10) {

                    fechaActual = ahora.getYear() + "/0" + ahora.getMonthValue() + "/" + ahora.getDayOfMonth();

                } else if (ahora.getDayOfMonth() < 10) {

                    fechaActual = ahora.getYear() + "/" + ahora.getMonthValue() + "/0" + ahora.getDayOfMonth();

                } else {

                    fechaActual = ahora.getYear() + "/" + ahora.getMonthValue() + "/" + ahora.getDayOfMonth();

                }

                // Insert en la BBDD

                sql = "insert into sugerencias(mensaje, fecha, dni) values(?,?,?)";
                ps = App.con.prepareStatement(sql);

                ps.setString(1, sugerencia.getText());
                ps.setString(2, fechaActual);
                ps.setString(3, LoginController.usuarioIniciado.getDni());
                ps.executeUpdate();

                // Insertar a la arraylist sugerencias

                // App.sugerencias.add(new sugerencia(sugerencia.getText(), fechaActual, LoginController.usuarioIniciado.getDni()));

                // Confirmacion

                Alert sugerenciaEnviada = new Alert(Alert.AlertType.CONFIRMATION);
                sugerenciaEnviada.setTitle("Sugerencia enviada con exito");
                sugerenciaEnviada.setContentText("Sugerencia: " + sugerencia.getText());
                sugerenciaEnviada.showAndWait();
                sugerencia.setText("");

            } catch (SQLException e) {

                Alert errorEnviarSugerencia = new Alert(Alert.AlertType.ERROR);
                errorEnviarSugerencia.setHeaderText("!! Error al enviar una sugerencia ¡¡");
                errorEnviarSugerencia.setContentText(e.getMessage());
                errorEnviarSugerencia.showAndWait();

            }

        } else {

            Alert errorEnviarSugerencia = new Alert(Alert.AlertType.ERROR);
            errorEnviarSugerencia.setHeaderText("!! Error al enviar una sugerencia ¡¡");
            errorEnviarSugerencia.setContentText("Debes escribir un mensaje");
            errorEnviarSugerencia.showAndWait();

        }

    } 

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("principal");
    }

    @FXML
    void initialize() {
        assert sugerencia != null : "fx:id=\"sugerencia\" was not injected: check your FXML file 'sugerencias.fxml'.";

    }

}