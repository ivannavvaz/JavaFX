package navigym;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class EliminarClaseController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView tablaClases;
    @FXML
    private TableColumn capacidadActualCL;
    @FXML
    private TableColumn capacidadCL;
    @FXML
    private TableColumn claseCL;
    @FXML
    private TableColumn fechaCL;
    @FXML
    private TableColumn idCL;
    ObservableList<clase> clases;

    clase claseSeleccionada = null;
    @FXML
    void eliminarClase(ActionEvent event) {

        if (clases.size() != 0) {

            claseSeleccionada = clases.get(tablaClases.getSelectionModel().getFocusedIndex());

            try {

                String SQL = "Delete from clases where id = '"
                        + claseSeleccionada.getId() + "'";
                Statement st = App.con.createStatement();
                st.executeUpdate(SQL);

            } catch (Exception e) {
                
                System.out.println(e.getMessage());

            }

        }

    }

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("admin");
    }

    private void inicializarTablaClases() {

        idCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("id"));
        claseCL.setCellValueFactory(new PropertyValueFactory<clase, String>("nombre"));
        fechaCL.setCellValueFactory(new PropertyValueFactory<clase, String>("fecha"));
        capacidadActualCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("capacidadActual"));
        capacidadCL.setCellValueFactory(new PropertyValueFactory<clase, Integer>("capacidad"));

        clases = FXCollections.observableArrayList();
        tablaClases.setItems(clases);

    }

    @FXML
    void initialize() {
        assert capacidadActualCL != null
                : "fx:id=\"capacidadActualCL\" was not injected: check your FXML file 'eliminarClase.fxml'.";
        assert capacidadCL != null
                : "fx:id=\"capacidadCL\" was not injected: check your FXML file 'eliminarClase.fxml'.";
        assert claseCL != null : "fx:id=\"claseCL\" was not injected: check your FXML file 'eliminarClase.fxml'.";
        assert fechaCL != null : "fx:id=\"fechaCL1\" was not injected: check your FXML file 'eliminarClase.fxml'.";
        assert idCL != null : "fx:id=\"idCL\" was not injected: check your FXML file 'eliminarClase.fxml'.";
        assert tablaClases != null
                : "fx:id=\"tablaClases\" was not injected: check your FXML file 'eliminarClase.fxml'.";
        this.inicializarTablaClases();

        try {

            App.con = App.conectar();
            Statement st = App.con.createStatement();
            ResultSet rs1 = st.executeQuery("SELECT * FROM clases");

            while (rs1.next()) {

                clases.add(new clase(rs1.getInt("id"), rs1.getString("nombre"), rs1.getInt("capacidadActual"),
                        rs1.getInt("capacidad"), rs1.getString("fecha"), rs1.getString("dni")));

            }

        } catch (Exception e) {

            System.out.println("ERROR - " + e.getMessage());

        }

    }

}
