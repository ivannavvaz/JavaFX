package navigym;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;


public class QrController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView imagenQr;

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("principal");
    }

    @FXML
    void initialize() {
        
    }

}
