package navigym;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

public class HorarioController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void volver(MouseEvent event) throws IOException {
        App.setRoot("principal");
    }

    @FXML
    void initialize() {

    }

}