module navigym {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens navigym to javafx.fxml;
    exports navigym;
}
